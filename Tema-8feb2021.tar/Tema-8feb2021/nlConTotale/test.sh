./nlConTotale uno.input
